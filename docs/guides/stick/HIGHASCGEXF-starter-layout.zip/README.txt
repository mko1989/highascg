HighAsCG operator exFAT layout (volume label must be HIGHASCGEXF)

Copy the contents of this zip onto the exFAT partition (not inside an extra folder).

Folders:
  drop-update/     Server hotfix drops (extract highascg-server_*.tar.gz here)
  drop-config/     Optional monolithic highascg.config.json overlay
  configs/         Modular settings + .highascg-state.json (starter show included)
  media/           Playout media library
  templates/       Caspar HTML/templates
  snapshots/rear-panels/  Rear-panel snapshots

Boot order on the playout machine:
  mount HIGHASCGEXF → apply drop-update/ → sync configs/ → start highascg.service

See docs/WO47_ISO_VS_EXFAT.md and docs/EXFAT_SERVER_UPDATE.md in the HighAsCG repo.
