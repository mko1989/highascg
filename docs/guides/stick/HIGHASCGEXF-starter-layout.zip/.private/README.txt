HighAsCG private volume root — per-machine subfolders are created at sync time.

  .private/<machine-id>/syncthing/   device ID, media folder manifest
  .private/<machine-id>/tailscale/   status snapshot (not tailscaled.state)
  .private/<machine-id>/replication/ pairing manifest (no peer token)

Not synced via configs/ or projects/. exFAT is not encrypted.
