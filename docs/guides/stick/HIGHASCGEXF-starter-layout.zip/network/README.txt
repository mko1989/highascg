Operator network settings — edit network.conf on the USB stick from any PC.

  network/network.conf   DHCP or static IPv4 (plain text, Notepad-friendly)

After saving, reboot the playout box or re-plug the USB stick.
Settings apply before the Web UI starts. Invalid values are skipped (fail-safe).

See network.conf for examples. Device View can also change IP at runtime;
exFAT file wins on the next cold boot.
