DeckLink Desktop Video — operator .deb files from Blackmagic tarball deb/x86_64/:

  desktopvideo_<version>_amd64.deb       required for Caspar decklink I/O
  desktopvideo-gui_<version>_amd64.deb    optional — Setup / Updater GUI only

Installed at boot when needed (skipped if already on system).
desktopvideo alone is enough when card firmware is current; without desktopvideo-gui
the Settings Desktop Video Setup button reports GUI not installed.
